﻿using Microsoft.AspNetCore.Mvc;

namespace Bosch.eCommerce.MVC.UI.Areas.Carts.Controllers
{
    [Area("Carts")]
    public class HomeController : Controller
    {
        public IActionResult YourCartItems()
        {
            return View("YourCartItems");
        }


    }
}
