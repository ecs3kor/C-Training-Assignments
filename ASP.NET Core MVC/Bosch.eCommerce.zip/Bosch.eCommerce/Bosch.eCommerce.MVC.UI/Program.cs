using Bosch.eCommerce.DAL;
using Bosch.eCommerce.Models;
using Bosch.eCommerce.Persistance;
using Microsoft.EntityFrameworkCore;
using System.Configuration;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddSession(options =>
{
    options.Cookie.IsEssential = true;
    options.Cookie.HttpOnly = true;
});
string ConStr = builder.Configuration.GetConnectionString("BoschECommerceConStr");
builder.Services.AddDbContext<ECommerceDBContext>(options =>
{
    options.UseSqlServer(ConStr);
});

builder.Services.Configure<RazorPaySettings>(builder.Configuration.GetSection("Razorpay"));
builder.Services.AddControllersWithViews();
builder.Services.AddTransient<ICommonRepository<Category>,CommonRepository<Category>>();
builder.Services.AddTransient<ICommonRepository<Product>, CommonRepository<Product>>();
builder.Services.AddTransient<ICommonRepository<Customer>, CommonRepository<Customer>>();
builder.Services.AddTransient<ICommonRepository<Cart>, CommonRepository<Cart>>();
builder.Services.AddTransient<ICommonRepository<CartItem>, CommonRepository<CartItem>>();
builder.Services.AddTransient<ICommonRepository<Invoice>, CommonRepository<Invoice>>();

builder.Services.AddAutoMapper(Assembly.Load(new AssemblyName("Bosch.eCommerce.MVC.UI")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseSession();
app.UseRouting();

app.UseAuthorization();


app.MapControllerRoute(
name: "areas",
pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
name: "default",
pattern: "{controller=Home}/{action=Index}/{id?}");






app.Run();
